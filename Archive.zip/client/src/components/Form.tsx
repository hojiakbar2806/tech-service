
const Form = () => {
  return (
    <div className='max-w-7xl'>

    </div>
  )
}

export default Form
